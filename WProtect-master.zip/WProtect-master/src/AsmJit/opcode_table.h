#ifndef OPCODE_TABLE_H_1ULVRWSE
#define OPCODE_TABLE_H_1ULVRWSE




extern const unsigned int instruction_table_count;
extern const char * instruction_table[575];    

 #endif /* end of include guard: OPCODE_TABLE_H_1ULVRWSE */ 
