#include <iostream>
#include <string.h>

using namespace std;

template <class T>  
T * upset(T * t,int nSize);
