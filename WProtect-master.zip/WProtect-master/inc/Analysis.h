/*typedef struct _ANALYSIS_OPTIONS_
{
	unsigned char * buff; //代码缓冲区
	unsigned long  size; //大小
    unsigned long base; // 基址
}AnalysisOption,*pAnalysisOption;
*/
typedef struct _CODE_INFORMATION_
{
	unsigned char * buff; //代码缓冲区
	unsigned long  size; //大小
    unsigned long base; // 基址
}CodeInformation,*pCodeInformation;

