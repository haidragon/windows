# WProtect

WProtect is an opensource project which uses code-virtualization technic to protect binary from being reverse-engineered or unwanted modified.
WProtect is a cross-platform project, and still under developing.
For now it supports CV for:
Windows 32bit.
Linux 32bit.
Arm protection and 64bit-support is still under developing.

You can get source code here:
https://github.com/xiaoweime/WProtect 

To build this project, you need:
git : to get the source code.
cmake : to configure the project.
gcc or mingw32 or MSVC10 to compile it.

Currently,other MSVC compilers and OSX-Clang are not supported.

Please report bugs/features in this post.
You are welcomed to join the project and contribute to it.

Greetings.
xiaoweime

QQ Group:210887170
